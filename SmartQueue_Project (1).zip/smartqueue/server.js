// SmartQueue server: serves the HTML pages from /public and gives them data from MongoDB.
const express = require('express'), mongoose = require('mongoose'), bcrypt = require('bcryptjs'),
      jwt = require('jsonwebtoken'), path = require('path');
const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
app.get('/api/health', (q, s) => s.json({ ok: true, db: mongoose.connection.readyState === 1 }));
app.use('/api', (q, s, next) => mongoose.connection.readyState === 1 ? next()      // block API calls while MongoDB is not connected
  : s.status(503).json({ error: 'Database not connected. Start MongoDB on your laptop, wait a few seconds, then try again.' }));

const SECRET = 'smartqueue-secret-key', PORT = 3000;
const MONGO_URL = 'mongodb://127.0.0.1:27017/smartqueue';   // local MongoDB on your laptop
const SERVICES = {
  A: { name: 'Account Opening', mins: 15 }, D: { name: 'Cash Deposit', mins: 3 },
  W: { name: 'Cash Withdrawal', mins: 4 },  B: { name: 'Bill Payment', mins: 3 },
  T: { name: 'Fund Transfer', mins: 5 }
};

// ---------- Collections (these match the classes in the class diagram) ----------
const { Schema, model } = mongoose, Oid = Schema.Types.ObjectId;
const User = model('User', new Schema({ name: String, username: { type: String, unique: true }, email: String,
  passwordHash: String, role: { type: String, enum: ['USER', 'ADMIN', 'MANAGER'], default: 'USER' }, createdAt: { type: Date, default: Date.now } }));
const Counter = model('Counter', new Schema({ number: Number, isOpen: { type: Boolean, default: true },
  adminName: String, current: { type: Oid, ref: 'Token', default: null }, served: { type: Number, default: 0 } }));
const Token = model('Token', new Schema({ tokenNo: String, serviceType: String, isPriority: { type: Boolean, default: false },
  status: { type: String, default: 'WAITING' },   // WAITING, SERVING, COMPLETED, REJECTED, CANCELLED
  userId: Oid, userName: String, counterNo: Number, issueTime: { type: Date, default: Date.now }, callTime: Date, completionTime: Date }));
const Request = model('ServiceRequest', new Schema({ tokenId: Oid, tokenNo: String, serviceType: String, accountNo: String,
  amount: { type: Number, default: 0 }, status: { type: String, default: 'PENDING' }, note: String, processedBy: String, createdAt: { type: Date, default: Date.now } }));
const Receipt = model('Receipt', new Schema({ receiptNo: String, tokenNo: String, serviceType: String, accountNo: String,
  amount: Number, processedBy: String, issuedAt: { type: Date, default: Date.now } }));
const Alert = model('Alert', new Schema({ type: String, message: String, createdAt: { type: Date, default: Date.now } }));
const AuditLog = model('AuditLog', new Schema({ userId: String, username: String, role: String, action: String, recordId: String, timestamp: { type: Date, default: Date.now } }));
const Setting = model('Setting', new Schema({ key: String, policy: String, maxWaiting: Number, maxWaitMinutes: Number }));

// ---------- Helpers ----------
const h = fn => (q, s) => fn(q, s).catch(e => s.status(500).json({ error: e.message }));
const log = (u, action, rec) => AuditLog.create({ userId: String(u.id || u._id), username: u.username, role: u.role, action, recordId: String(rec || '') });
const settings = async () => (await Setting.findOne({ key: 'main' })) || Setting.create({ key: 'main', policy: 'fcfs', maxWaiting: 5, maxWaitMinutes: 5 });
const auth = (...roles) => (q, s, next) => {              // login check + role-based access
  try {
    q.user = jwt.verify((q.headers.authorization || '').replace('Bearer ', ''), SECRET);
    if (roles.length && !roles.includes(q.user.role)) return s.status(403).json({ error: 'Not allowed for your role' });
    next();
  } catch (e) { s.status(401).json({ error: 'Please log in' }); }
};
async function ordered() {                                  // queue order depends on the chosen policy
  const set = await settings(), now = Date.now();
  const score = {
    fcfs: t => +t.issueTime,
    priority: t => (t.isPriority ? 0 : 1e15) + +t.issueTime,
    short: t => SERVICES[t.serviceType].mins - ((now - t.issueTime) / 60000) * 0.5 - (t.isPriority ? 100 : 0)   // shortest first + ageing
  }[set.policy];
  return (await Token.find({ status: 'WAITING' }).lean()).sort((a, b) => score(a) - score(b));
}
async function raise(type, message) {                       // create an alert (not more than once per 3 min)
  if (!(await Alert.findOne({ type, createdAt: { $gt: new Date(Date.now() - 180000) } }))) await Alert.create({ type, message });
}

// ---------- Authentication ----------
app.post('/api/auth/register', h(async (q, s) => {
  const { name, username, email, password } = q.body;
  if (!name || !username || !password || password.length < 4) return s.status(400).json({ error: 'Fill all fields (password: minimum 4 characters)' });
  if (await User.findOne({ username })) return s.status(400).json({ error: 'Username already taken' });
  const u = await User.create({ name, username, email, passwordHash: await bcrypt.hash(password, 10) });
  await log(u, 'User registered', u.username); s.json({ ok: true });
}));
app.post('/api/auth/login', h(async (q, s) => {
  const u = await User.findOne({ username: q.body.username });
  if (!u || !(await bcrypt.compare(q.body.password || '', u.passwordHash))) return s.status(401).json({ error: 'Wrong username or password' });
  const user = { id: u._id, name: u.name, username: u.username, role: u.role };
  await log(user, 'Login', u.username);
  s.json({ token: jwt.sign(user, SECRET, { expiresIn: '8h' }), user });
}));

// ---------- User ----------
app.post('/api/tokens', auth('USER'), h(async (q, s) => {
  const { serviceType, isPriority } = q.body;
  if (!SERVICES[serviceType]) return s.status(400).json({ error: 'Choose a service' });
  const active = await Token.findOne({ userId: q.user.id, status: { $in: ['WAITING', 'SERVING'] } });
  if (active) return s.status(400).json({ error: 'You already have an active token (' + active.tokenNo + ')' });
  const n = (await Token.countDocuments({ serviceType })) + 1;
  const t = await Token.create({ tokenNo: serviceType + '-' + String(n).padStart(3, '0'), serviceType, isPriority: !!isPriority, userId: q.user.id, userName: q.user.name });
  await Request.create({ tokenId: t._id, tokenNo: t.tokenNo, serviceType });
  await log(q.user, 'Token issued', t.tokenNo); s.json(t);
}));
app.get('/api/tokens/mine', auth('USER'), h(async (q, s) => {
  const list = await Token.find({ userId: q.user.id }).sort({ issueTime: -1 }).limit(50).lean();
  const open = await Counter.countDocuments({ isOpen: true });
  for (const t of list) {
    if (t.status === 'WAITING') {
      t.ahead = await Token.countDocuments({ status: 'WAITING', issueTime: { $lt: t.issueTime } });
      t.estWait = Math.max(1, Math.round(t.ahead * 4 / Math.max(1, open)));
    }
    if (t.status === 'COMPLETED') t.receipt = await Receipt.findOne({ tokenNo: t.tokenNo }).lean();
  }
  s.json(list);
}));
app.post('/api/tokens/:id/cancel', auth('USER'), h(async (q, s) => {
  const t = await Token.findOne({ _id: q.params.id, userId: q.user.id, status: 'WAITING' });
  if (!t) return s.status(400).json({ error: 'Token cannot be cancelled' });
  t.status = 'CANCELLED'; await t.save(); await Request.updateOne({ tokenId: t._id }, { status: 'CANCELLED' });
  await log(q.user, 'Token cancelled', t.tokenNo); s.json({ ok: true });
}));
app.get('/api/queue/status', auth(), h(async (q, s) => {
  const waiting = await Token.countDocuments({ status: 'WAITING' }), open = await Counter.countDocuments({ isOpen: true });
  s.json({ waiting, openCounters: open, estWait: Math.round(waiting * 4 / Math.max(1, open)), serving: await Token.find({ status: 'SERVING' }).select('tokenNo counterNo') });
}));

// ---------- Administrator ----------
app.get('/api/admin/queue', auth('ADMIN'), h(async (q, s) => s.json(await ordered())));
app.get('/api/admin/counters', auth('ADMIN'), h(async (q, s) => {
  const cs = await Counter.find().sort({ number: 1 }).populate('current').lean();
  for (const c of cs) if (c.current) c.request = await Request.findOne({ tokenId: c.current._id }).lean();
  s.json(cs);
}));
app.post('/api/admin/call', auth('ADMIN'), h(async (q, s) => {
  const c = await Counter.findById(q.body.counterId);
  if (!c || !c.isOpen) return s.status(400).json({ error: 'Counter is closed' });
  if (c.current) return s.status(400).json({ error: 'Finish the current token first' });
  const first = (await ordered())[0];
  if (!first) return s.status(404).json({ error: 'No customers waiting' });
  const t = await Token.findById(first._id);
  t.status = 'SERVING'; t.callTime = new Date(); t.counterNo = c.number; await t.save();
  c.current = t._id; c.adminName = q.user.name; await c.save();
  await log(q.user, 'Token called (Counter ' + c.number + ')', t.tokenNo); s.json(t);
}));
app.post('/api/admin/process', auth('ADMIN'), h(async (q, s) => {
  const { tokenId, approve, accountNo, amount } = q.body;
  const t = await Token.findOne({ _id: tokenId, status: 'SERVING' }), r = await Request.findOne({ tokenId }), c = await Counter.findOne({ current: tokenId });
  if (!t || !r) return s.status(400).json({ error: 'Token is not being served' });
  let ok = !!approve, note = '';
  if (ok && !String(accountNo || '').trim()) return s.status(400).json({ error: 'Enter ' + (t.serviceType === 'A' ? 'applicant name' : 'account number') });
  if (ok && t.serviceType !== 'A' && !(amount > 0)) return s.status(400).json({ error: 'Enter a valid amount' });
  if (ok && t.serviceType === 'W' && amount > 50000) { ok = false; note = 'Insufficient balance (demo limit Rs. 50,000)'; }   // verification step
  Object.assign(r, { accountNo, amount: amount || 0, status: ok ? 'APPROVED' : 'REJECTED', note, processedBy: q.user.name }); await r.save();
  t.status = ok ? 'COMPLETED' : 'REJECTED'; t.completionTime = new Date(); await t.save();
  if (c) { c.current = null; if (ok) c.served++; await c.save(); }
  if (ok) await Receipt.create({ receiptNo: 'R-' + Date.now().toString().slice(-7), tokenNo: t.tokenNo, serviceType: t.serviceType, accountNo, amount, processedBy: q.user.name });
  await log(q.user, (ok ? 'Approved & completed ' : 'Rejected ') + SERVICES[t.serviceType].name, t.tokenNo);
  s.json({ ok, note });
}));
app.get('/api/admin/users', auth('ADMIN'), h(async (q, s) => s.json(await User.find().select('-passwordHash').sort({ createdAt: 1 }))));
app.post('/api/admin/users', auth('ADMIN'), h(async (q, s) => {
  const { name, username, password, role } = q.body;
  if (!name || !username || !password) return s.status(400).json({ error: 'Fill all fields' });
  if (await User.findOne({ username })) return s.status(400).json({ error: 'Username already taken' });
  const u = await User.create({ name, username, role, passwordHash: await bcrypt.hash(password, 10) });
  await log(q.user, 'User created (' + role + ')', username); s.json(u);
}));
app.delete('/api/admin/users/:id', auth('ADMIN'), h(async (q, s) => {
  if (q.params.id === q.user.id) return s.status(400).json({ error: 'You cannot delete yourself' });
  const u = await User.findByIdAndDelete(q.params.id); if (u) await log(q.user, 'User deleted', u.username); s.json({ ok: true });
}));
app.post('/api/admin/counters', auth('ADMIN'), h(async (q, s) => {
  const n = (await Counter.countDocuments()) + 1; await Counter.create({ number: n }); await log(q.user, 'Counter added', 'Counter ' + n); s.json({ ok: true });
}));
app.patch('/api/admin/counters/:id', auth('ADMIN'), h(async (q, s) => {
  const c = await Counter.findById(q.params.id);
  if (c.current) return s.status(400).json({ error: 'Counter is serving a token' });
  c.isOpen = !c.isOpen; await c.save(); await log(q.user, 'Counter ' + (c.isOpen ? 'opened' : 'closed'), 'Counter ' + c.number); s.json({ ok: true });
}));
app.get('/api/settings', auth(), h(async (q, s) => s.json(await settings())));
app.put('/api/settings', auth('ADMIN'), h(async (q, s) => {
  const { policy, maxWaiting, maxWaitMinutes } = q.body;
  await Setting.updateOne({ key: 'main' }, { policy, maxWaiting, maxWaitMinutes }); await log(q.user, 'Settings changed', policy + ' / ' + maxWaiting + ' / ' + maxWaitMinutes); s.json({ ok: true });
}));

// ---------- Dashboard numbers (Administrator + Manager) ----------
app.get('/api/summary', auth('MANAGER', 'ADMIN'), h(async (q, s) => {
  const set = await settings(), d0 = new Date(); d0.setHours(0, 0, 0, 0);
  const waiting = await Token.find({ status: 'WAITING' }).lean(), today = await Token.find({ issueTime: { $gte: d0 } }).lean();
  const done = today.filter(t => t.status === 'COMPLETED'), called = today.filter(t => t.callTime);
  const avgWait = called.length ? called.reduce((a, t) => a + (t.callTime - t.issueTime), 0) / called.length / 60000 : 0;
  const longest = waiting.length ? Math.max(...waiting.map(t => Date.now() - t.issueTime)) / 60000 : 0;
  const counters = await Counter.find().sort({ number: 1 }).lean();
  counters.forEach(c => c.servedToday = done.filter(t => t.counterNo === c.number).length);
  const byService = {}; done.forEach(t => byService[t.serviceType] = (byService[t.serviceType] || 0) + 1);
  const active = [], tooLong = waiting.filter(t => (Date.now() - t.issueTime) / 60000 > set.maxWaitMinutes).length;
  if (waiting.length > set.maxWaiting) { const m = `Long queue: ${waiting.length} customers waiting (limit ${set.maxWaiting})`; active.push(m); await raise('LONG_QUEUE', m); }
  if (tooLong) { const m = `Excessive waiting: ${tooLong} customer(s) waiting more than ${set.maxWaitMinutes} min`; active.push(m); await raise('LONG_WAIT', m); }
  s.json({ waiting: waiting.length, servedToday: done.length, avgWait, longest, counters, byService, active, settings: set,
           alerts: await Alert.find().sort({ createdAt: -1 }).limit(8).lean() });
}));

// ---------- Manager: historical report + audit ----------
app.get('/api/report', auth('MANAGER'), h(async (q, s) => {
  const days = +q.query.days || 7, from = new Date(); from.setHours(0, 0, 0, 0); from.setDate(from.getDate() - days + 1);
  const ts = await Token.find({ issueTime: { $gte: from }, status: 'COMPLETED' }).lean();
  const day = {}, hour = {}, svc = {};
  ts.forEach(t => {
    const w = (t.callTime - t.issueTime) / 60000, sv = (t.completionTime - t.callTime) / 60000, dk = new Date(t.issueTime).toLocaleDateString('en-CA');
    (day[dk] = day[dk] || []).push(w); hour[new Date(t.issueTime).getHours()] = (hour[new Date(t.issueTime).getHours()] || 0) + 1;
    (svc[t.serviceType] = svc[t.serviceType] || []).push(sv);
  });
  const avg = a => a.length ? a.reduce((x, y) => x + y, 0) / a.length : 0, all = ts.map(t => (t.callTime - t.issueTime) / 60000);
  s.json({ totals: { served: ts.length, avgWait: avg(all) },
    byDay: Object.keys(day).sort().map(d => ({ date: d, served: day[d].length, avgWait: avg(day[d]) })),
    byHour: Object.keys(hour).map(k => ({ hour: +k, count: hour[k] })),
    byService: Object.keys(svc).map(c => ({ code: c, name: SERVICES[c].name, count: svc[c].length, avgService: avg(svc[c]) })) });
}));
app.get('/api/audit', auth('MANAGER'), h(async (q, s) => s.json(await AuditLog.find().sort({ timestamp: -1 }).limit(200))));

// ---------- First-run demo data ----------
async function seed() {
  if (await User.countDocuments()) return;
  const hash = p => bcrypt.hash(p, 10);
  await User.create([{ name: 'Branch Administrator', username: 'admin', role: 'ADMIN', passwordHash: await hash('admin123') },
    { name: 'Branch Manager', username: 'manager', role: 'MANAGER', passwordHash: await hash('manager123') },
    { name: 'Ahmed Khan', username: 'user', role: 'USER', email: 'ahmed@example.com', passwordHash: await hash('user123') }]);
  await Counter.create([{ number: 1 }, { number: 2 }, { number: 3 }]); await settings();
  const seq = {}, rows = [], codes = Object.keys(SERVICES);          // sample history for the last 7 days so reports have data
  for (let d = 1; d <= 7; d++) for (let i = 0; i < 8 + Math.floor(Math.random() * 7); i++) {
    const c = codes[Math.floor(Math.random() * 5)], hr = [9, 10, 11, 12, 12, 13, 13, 14, 15, 16][Math.floor(Math.random() * 10)];
    const issue = new Date(); issue.setDate(issue.getDate() - d); issue.setHours(hr, Math.floor(Math.random() * 60), 0, 0);
    const wait = 2 + Math.random() * 8 + (hr >= 12 && hr <= 14 ? 5 : 0), sv = SERVICES[c].mins * (0.7 + Math.random() * 0.7);
    seq[c] = (seq[c] || 0) + 1;
    rows.push({ tokenNo: c + '-' + String(seq[c]).padStart(3, '0'), serviceType: c, status: 'COMPLETED', userName: 'Walk-in', counterNo: 1 + Math.floor(Math.random() * 3),
      issueTime: issue, callTime: new Date(+issue + wait * 60000), completionTime: new Date(+issue + (wait + sv) * 60000) });
  }
  await Token.insertMany(rows); console.log('Demo data created.');
}

app.listen(PORT, () => console.log('SmartQueue running: http://localhost:' + PORT))
  .on('error', e => console.log('\nCannot start server: ' + e.message + (e.code === 'EADDRINUSE' ? '\nPort 3000 is already used. Close the other terminal running SmartQueue.' : '')));
function connectDb() {                                       // keeps retrying until MongoDB is running
  mongoose.connect(MONGO_URL, { serverSelectionTimeoutMS: 4000 }).then(seed).then(() => console.log('MongoDB connected: smartqueue'))
    .catch(e => { console.log('MongoDB not reachable (' + e.message + ')\nStart MongoDB. Retrying in 5 seconds...'); setTimeout(connectDb, 5000); });
}
connectDb();
