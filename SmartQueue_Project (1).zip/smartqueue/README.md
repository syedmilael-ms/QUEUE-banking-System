# SmartQueue – Bank Branch Queue Management (Front-end + MongoDB)

Plain HTML + CSS + a little JavaScript for the screens, a small Node.js server, and a local MongoDB database on your laptop.

## How to run (Windows / Mac / Linux)
1. Install **Node.js** (LTS) from nodejs.org.
2. Install **MongoDB Community Server** from mongodb.com/try/download/community and make sure it is running
   (on Windows it installs as a service; default address `mongodb://127.0.0.1:27017`). MongoDB Compass is optional, to look at the data.
3. Open a terminal in this folder and run:
   ```
   npm install
   npm start
   ```
4. Open **http://localhost:3000** in your browser.

The first start creates the database `smartqueue`, the demo accounts, 3 counters and 7 days of sample history.

**Shortcut:** Windows – double-click `start.bat`. Mac/Linux – run `sh start.sh`.

## If login or register does not work
1. **Always open http://localhost:3000.** Double-clicking an .html file will not work, because the pages need the server.
2. The terminal running `npm start` must stay open. It should print `SmartQueue running` and `MongoDB connected: smartqueue`.
3. If it prints `MongoDB not reachable`, start MongoDB: on Windows open *Services* and start **MongoDB Server** (or run `net start MongoDB` in an Administrator terminal); on Mac `brew services start mongodb-community`; on Linux `sudo systemctl start mongod`.
4. Check `node -v` shows version 18 or newer.
5. The login and register pages show a red banner telling you which of these is the problem.

## Demo accounts
| Role | Username | Password |
|---|---|---|
| User (customer) | user | user123 |
| Administrator | admin | admin123 |
| Manager | manager | manager123 |

## Screens
| File | Who | What it does |
|---|---|---|
| index.html | everyone | Login |
| register.html | customer | Create account |
| user-token.html | User | Choose service, get token, live position and wait, cancel |
| user-history.html | User | Past tokens and receipts |
| admin-dashboard.html | Administrator | Waiting queue, call next token, verify and approve/reject, complete and generate receipt |
| admin-manage.html | Administrator | Users and roles, counters, queue policy, alert limits |
| manager-dashboard.html | Manager | Live monitoring, alerts, counter workload (read-only) |
| manager-reports.html | Manager | Historical analysis, peak hours, service analysis |
| manager-audit.html | Manager | Audit log with search |

## Folder structure
```
server.js          Node server + MongoDB collections + all API routes
public/css/style.css   All styling (one file)
public/js/common.js    Shared helpers: API calls, login check, sidebar
public/*.html          One page per screen
```

## MongoDB collections (match the class diagram)
User, Token, ServiceRequest, Receipt, Counter, Alert, AuditLog, Setting.

## Notes for the demo
- Waiting times are real minutes. To see alerts quickly, open Manage System and set the limits low (for example 2 customers, 1 minute), then get a few tokens.
- Passwords are stored hashed (bcrypt); logins use a JWT; every route checks the role.
- A browser cannot talk to MongoDB directly, so the small Node server sits in the middle.
