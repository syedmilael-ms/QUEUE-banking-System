// Shared helpers used by every page: talking to the server, login check, sidebar layout.
const SERVICES = { A: 'Account Opening', D: 'Cash Deposit', W: 'Cash Withdrawal', B: 'Bill Payment', T: 'Fund Transfer' };
const ICONS = { A: '📝', D: '💵', W: '💸', B: '🧾', T: '💰' };
const NAV = {   // which menu each role sees (role-based access)
  USER:    [['user-token.html', '🎟️  Get Token'], ['user-history.html', '📋  My History']],
  ADMIN:   [['admin-dashboard.html', '🖥️  Queue Dashboard'], ['admin-manage.html', '⚙️  Manage System']],
  MANAGER: [['manager-dashboard.html', '📊  Live Dashboard'], ['manager-reports.html', '📈  Reports'], ['manager-audit.html', '🔐  Audit Records']]
};
const HOME = { USER: 'user-token.html', ADMIN: 'admin-dashboard.html', MANAGER: 'manager-dashboard.html' };
const $ = id => document.getElementById(id);
const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const me = () => JSON.parse(localStorage.getItem('sq_user') || 'null');
const logout = () => { localStorage.clear(); location.href = 'index.html'; };
const dur = ms => { const s = Math.max(0, Math.floor(ms / 1000)); return Math.floor(s / 60) + 'm ' + String(s % 60).padStart(2, '0') + 's'; };
const tm = d => new Date(d).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
const dt = d => new Date(d).toLocaleString([], { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });
const badge = s => `<span class="badge ${s}">${s}</span>`;

async function api(path, method, body) {            // every page calls the server through this one function
  if (location.protocol === 'file:') throw new Error('Open the app at http://localhost:3000 (do not double-click the HTML file).');
  let r;
  try { r = await fetch('/api' + path, { method: method || 'GET',
    headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + (localStorage.getItem('sq_token') || '') },
    body: body ? JSON.stringify(body) : undefined }); }
  catch (e) { throw new Error('Cannot reach the server. Run "npm start" in the project folder, then open http://localhost:3000'); }
  const d = await r.json().catch(() => ({}));
  if (r.status === 401 && path !== '/auth/login') logout();
  if (!r.ok) throw new Error(d.error || 'Request failed');
  return d;
}
function toast(msg, bad) {
  const t = document.createElement('div'); t.className = 'toast' + (bad ? ' bad' : ''); t.textContent = msg;
  $('toast').appendChild(t); setTimeout(() => t.remove(), 3500);
}
async function run(fn, okMsg) { try { await fn(); if (okMsg) toast(okMsg); } catch (e) { toast(e.message, true); } }

// Builds sidebar + top bar around the page content. Sends the visitor to login if the role is wrong.
function layout(role, title) {
  const u = me();
  if (!u || u.role !== role) { location.href = 'index.html'; return false; }
  const page = document.getElementById('page');
  const nav = NAV[role].map(([h, l]) => `<a href="${h}" class="${location.pathname.endsWith(h) ? 'on' : ''}">${l}</a>`).join('');
  document.body.innerHTML = `<div class="app"><aside class="side"><div class="brand">🏦 SmartQueue<small>Branch Queue System</small></div>
    <nav>${nav}</nav><button class="logout" onclick="logout()">Log out</button></aside>
    <main><header class="top"><h1>${title}</h1><div class="who"><span class="pill">${role}</span>${esc(u.name)}</div></header>
    <section id="slot"></section></main></div><div id="toast"></div>`;
  $('slot').appendChild(page);
  return true;
}

// Shows a red banner on login/register if the server or MongoDB is not running.
async function checkServer() {
  const box = document.getElementById('srv'); if (!box) return;
  const bad = m => box.innerHTML = '<div class="alert bad">' + m + '</div>';
  if (location.protocol === 'file:') return bad('You opened the file directly. Run <b>npm start</b> in the project folder and open <b>http://localhost:3000</b>.');
  try { const h = await (await fetch('/api/health')).json(); if (!h.db) bad('Server is running but <b>MongoDB is not connected</b>. Start MongoDB on your laptop.'); }
  catch (e) { bad('Cannot reach the server. Run <b>npm start</b> in the project folder.'); }
}
